#define USPLASH_FIFO "usplash_fifo"
#define DEBUG 1
