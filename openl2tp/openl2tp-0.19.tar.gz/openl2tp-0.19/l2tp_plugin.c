/*****************************************************************************
 * Copyright (C) 2004,2005,2006,2007 Katalix Systems Ltd
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 *
 *****************************************************************************/

/*
 * Plugin support
 */

#include <stdlib.h>
#include <syslog.h>
#include <string.h>
#include <pwd.h>
#include <dlfcn.h>

#include "usl.h"
#include "l2tp_private.h"

struct l2tp_plugin {
	struct usl_list_head list;
	char *name;
	void *handle;
};

static USL_LIST_HEAD(l2tp_plugin_list);


int l2tp_plugin_load(char *name)
{
	const char *err;
	void (*init)(void);
	char *path;
	const char *vers;
	struct l2tp_plugin *plugin;

	if (strchr(name, '/') == 0) {
		const char *base = L2TP_PLUGIN_DIR;
		int len = strlen(base) + strlen(name) + 2;
		path = malloc(len);
		if (path == NULL) {
			l2tp_log(LOG_ERR, "OOM: plugin file path");
			return -ENOMEM;
		}

		strncpy(path, base, len);
		strncat(path, "/", len);
		strncat(path, name, len);
	} else {
		path = strdup(name);
		if (path == NULL) {
			l2tp_log(LOG_ERR, "OOM: plugin file path");
			return -ENOMEM;
		}
	}

	plugin = calloc(1, sizeof(*plugin));
	if (plugin == NULL) {
		goto err_free_path;
	}
	plugin->name = path;
	USL_LIST_HEAD_INIT(&plugin->list);

	plugin->handle = dlopen(path, RTLD_GLOBAL | RTLD_NOW);
	if (plugin->handle == 0) {
		err = dlerror();
		if (err != 0)
			l2tp_log(LOG_ERR, "%s", err);
		l2tp_log(LOG_ERR, "Couldn't load plugin %s", name);
		goto err_free_plugin;
	}
	init = (void (*)(void)) dlsym(plugin->handle, "openl2tp_plugin_init");
	if (init == 0) {
		l2tp_log(LOG_ERR, "%s has no initialization entry point", name);
		goto err_close;
	}
	vers = (const char *) dlsym(plugin->handle, "openl2tp_plugin_version");
	if (vers == NULL) {
		l2tp_log(LOG_ERR, "%s has no version information", name);
		goto err_close;
	}

	usl_list_add(&plugin->list, &l2tp_plugin_list);

	l2tp_log(LOG_INFO, "Loading plugin %s, version %s", name, vers);
	(*init)();

	return 0;

err_close:
	dlclose(plugin->handle);
err_free_plugin:
	free(plugin);
err_free_path:
	if (path != name)
		free(path);

	return -EINVAL;
}

int l2tp_plugin_init(void)
{
	/* Command line parser loads plugins. Nothing to do here */
	return 0;
}

void l2tp_plugin_cleanup(void)
{
	struct l2tp_plugin *plugin;
	struct usl_list_head *tmp;
	struct usl_list_head *walk;
	void (*cleanup)(void);

	/* Call cleanup functions of every loaded plugin */
	usl_list_for_each(walk, tmp, &l2tp_plugin_list) {
		plugin = usl_list_entry(walk, struct l2tp_plugin, list);
		l2tp_log(LOG_INFO, "Unloading plugin %s", plugin->name);
		cleanup = (void (*)(void))dlsym(plugin->handle, "openl2tp_plugin_cleanup");
		if (cleanup != NULL) {
			(*cleanup)();
		}
		dlclose(plugin->handle);
		free(plugin->name);
		usl_list_del(&plugin->list);
		free(plugin);
	}
}
