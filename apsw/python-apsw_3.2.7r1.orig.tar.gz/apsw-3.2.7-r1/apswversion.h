#define APSW_VERSION "3.2.7-r1"
