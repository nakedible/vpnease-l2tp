"""
Copyright (c) 2003  Gustavo Niemeyer <niemeyer@conectiva.com>

This module offers extensions to the standard python 2.3+
datetime module.
"""
__author__ = "Gustavo Niemeyer <niemeyer@conectiva.com>"
__license__ = "PSF License"
