Open-source patches in Stinghorn SBS
====================================


This archive contains all vendor-made modifications to open-source
software components included in Stinghorn SBS product.

The modifications were made to the Linux kernel (UML architecture),
OpenSWAN Pluto daemon (version 2.4.0rc4), L2TPd daemon (version
0.70-pre20031121), libgc (version 6.5), Racoon ISAKMP daemon in
IPsec-Tools package, amavisd-new and RRDcollect.



Archive contents
----------------

readme.txt
ipsec-tools-0.3.3-ssbs.diff
kernel-source-2.6.9-bs5-guest-cmdline.diff
rrdcollect-0.2.3-stinghorn.diff
rrdcollect-detick.diff
L2TP_Gateway
|-- kernel-source-2.6.9-bs5-l2tp-osx.diff
|-- l2tpd-bugs.patch
|-- l2tpd-gcc40.patch
|-- l2tpd-keepalive.patch
|-- l2tpd-libgc.patch
|-- libgc-6.5-2nothreads.diff
|-- openswan-2.4.0rc4-dynamic-peer-psk.patch
|-- openswan-2.4.0rc4-l2tp+osx-sa.patch
`-- openswan-2.4.0rc4-natt-fix.patch
Site-to-site_VPN
|-- openswan-2.4.0dr8-aggrmode.patch
|-- openswan-2.4.0rc4-dynamic-peer-psk.patch
|-- openswan-2.4.0rc4-inbound-sa.patch
|-- openswan-2.4.0rc4-natt-fix.patch
|-- openswan-2.4.0rc4-nattpatch-nocreate.patch
`-- openswan-2.4.0rc4-niscc-273756.patch
SMTP_Scan
`-- amavisd-2.3.3-no-dircheck.diff


Description of individual files
-------------------------------

 * readme.txt: This file.

 * ipsec-tools-0.3.3-ssbs.diff: Includes now obsolete patch for Racoon
   ISAKMP daemon used in older SBS versions.

 * kernel-source-2.6.9-bs5-guest-cmdline.diff: A patch against User
   Mode Linux quest kernel version 2.6.9-bs5 that increases the
   maximum command-line length.

 * rrdcollect-detick.diff: Removes needless syslog calls from
   rrdcollect.

 * rrdcollect-0.2.3-stinghorn.diff: Patch against Debian's
   rrdcollect-0.2.3 source package, which incorporates
   rrdcollect-detick.diff to automatically patch the sources when
   building a customised package.

 * L2TP patches:

   * kernel-source-2.6.9-bs5-l2tp-osx.diff and
     openswan-2.4.0rc4-l2tp+osx-sa.patch:

     Enables MAC OS X (Panther and Tiger) NAT-T support even for many
     L2TP clients connect from behind the same NAT device.

     Also includes backported fixes for NISCC Vulnerability Advisory
     273756/NISCC/ISAKMP. See http://www.openswan.org/niscc2/.

     Includes also a change to install both IPsec SAs after the last
     quick-mode message and not earlier. This avoids at least one race
     condition where SA expiry happens at the same time when there is
     a half-installed IPsec SA.

   * l2tpd-bugs.patch: This fixes some minor but important bugs and
     problems in l2tpd related to select() return values and
     tunnel/call id handling.

   * l2tpd-gcc40.patch: This patch enables l2tpd to compile using
     GCC version 4.0.

   * l2tpd-keepalive.patch: L2TPd daemon patch that increases the time
     between the server-side keep-alive messages.

   * l2tpd-libgc.patch: Build and run l2tpd using libgc.

   * libgc-6.5-2nothreads.diff: Build libgc without threads support
     to allow using it under UML Linux kernel.

   * openswan-2.4.0rc4-dynamic-peer-psk.patch: Allows multiple dynamic
     (%any) endpoints when using aggressive mode and pre-shared keys.

   * openswan-2.4.0rc4-natt-fix.patch: Fix NAT-T payload chaining in
     aggressive mode (and pre-shared keys).



 * Site-to-site VPN patches:

   * openswan-2.4.0dr8-aggrmode.patch: Sidestep various problems
     related to NAT traversal port floating and Delete SA
     notifications in aggressive mode.

   * openswan-2.4.0rc4-dynamic-peer-psk.patch: Allows using pre-shared
     keys with dynamic peers.

   * openswan-2.4.0rc4-inbound-sa.patch: A change to install both
     IPsec SAs after the last quick-mode message and not earlier. This
     avoids at least one race condition where SA expiry happens at the
     same time when there is a half-installed IPsec SA.

   * openswan-2.4.0rc4-natt-fix.patch: Fix NAT-traversal payload
     chaining bug.

   * openswan-2.4.0rc4-nattpatch-nocreate.patch: Prevent the creation
     of NAT-T kernel patch at the time of dpkg packaging.

   * openswan-2.4.0rc4-niscc-273756.patch: Includes backported fixes
     for NISCC Vulnerability Advisory 273756/NISCC/ISAKMP. See
     http://www.openswan.org/niscc2/.


 * SMTP Scanner patches:

    * amavisd-2.3.3-no-dircheck.diff: Removes configuration file's directory
      permission checking from amavisd-new, which does not really add
      security. Allows to dynamically (re)create domains' configuration
      files with ease.

