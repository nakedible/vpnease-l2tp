#ifndef _OTHER_H
#define _OTHER_H

/* define the function */

void other_function(void);

#endif /*_OTHER_H*/
