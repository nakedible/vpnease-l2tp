/*
 * some of this seems like a repeat of rlm_eap, and needs to be better
 * integrated, but as a client library, it deals with Request/Replies
 * rather than with Replies -> new requests.
 *
 * Bare with me for a bit.
 *
 */
