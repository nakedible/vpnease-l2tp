"""Tests for the examples, and some functional tests for nevow itself. 
"""