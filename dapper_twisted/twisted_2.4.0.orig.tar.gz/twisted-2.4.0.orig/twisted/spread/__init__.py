
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Spread: Spreadable (Distributed) Computing.

Stability: semi-stable

Future Plans: PB, Jelly and Banana need to be optimized.

@author: U{Glyph Lefkowitz<mailto:glyph@twistedmatrix.com>}
"""
