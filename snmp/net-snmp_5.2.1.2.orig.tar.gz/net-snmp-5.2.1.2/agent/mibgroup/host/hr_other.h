void            init_hr_other(void);
