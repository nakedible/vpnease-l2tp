#ifndef NOTIFICATION_H
#define NOTIFICATION_H

/* prototypes for the example */
void init_notification(void);
SNMPAlarmCallback send_example_notification;

#endif /* NOTIFICATION_H */
