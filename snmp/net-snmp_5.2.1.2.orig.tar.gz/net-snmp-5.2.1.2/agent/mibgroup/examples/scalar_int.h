#ifndef SCALAR_INT_H
#define SCALAR_INT_H

void            init_example_scalar(void);

#endif                          /* SCALAR_INT_H */
