Netsnmp_Node_Handler delayed_instance_handler;
void            init_delayed_instance(void);
SNMPAlarmCallback return_delayed_response;
