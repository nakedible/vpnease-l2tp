/*
 * module to include the modules
 */

config_require(if-mib/ifXTable/ifXTable);

config_require(if-mib/data_access/interface);
config_require(if-mib/ifXTable/ifXTable_interface);
config_require(if-mib/ifXTable/ifXTable_data_access);

