/*
 * Copyright (C), 2000-2006 by the monit project group.
 * All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <config.h>

#ifdef HAVE_STDIO_H
#include <stdio.h>
#endif

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#include "protocol.h"

/* Private variables */
static Protocol_T myapache_status= NULL;
static Protocol_T mydefault= NULL;
static Protocol_T mydns= NULL;
static Protocol_T mydwp= NULL;
static Protocol_T myftp= NULL;
static Protocol_T mygeneric= NULL;
static Protocol_T myhttp= NULL;
static Protocol_T myimap= NULL;
static Protocol_T myldap2= NULL;
static Protocol_T myldap3= NULL;
static Protocol_T mymysql= NULL;
static Protocol_T mynntp= NULL;
static Protocol_T myntp3= NULL;
static Protocol_T mypostfix_policy= NULL;
static Protocol_T mypop= NULL;
static Protocol_T mysmtp= NULL;
static Protocol_T myssh= NULL;
static Protocol_T myrdate= NULL;
static Protocol_T myrsync= NULL;
static Protocol_T mytns= NULL;
static Protocol_T mypgsql= NULL;


/**
 *  Factory module for vending protocol objects. Using lazy
 *  initialization, and dishing out only one copy of the object.
 *
 *  @author Jan-Henrik Haukeland, <hauk@tildeslash.com>
 *
 *  @version \$Id: protocol.c,v 1.27 2006/01/22 19:47:36 hauk Exp $
 *
 *  @file
 */


/* ------------------------------------------------------------------ Public */


void gc_protocols() {

  FREE(myapache_status);
  FREE(mydefault);
  FREE(mydns);
  FREE(mydwp);
  FREE(myftp);
  FREE(mygeneric);
  FREE(myhttp);
  FREE(myimap);
  FREE(myldap2);
  FREE(myldap3);
  FREE(mymysql);
  FREE(mynntp);
  FREE(myntp3);
  FREE(mypostfix_policy);
  FREE(mypop);
  FREE(mysmtp);
  FREE(myssh);
  FREE(myrdate);
  FREE(myrsync);
  FREE(mytns);
  FREE(mypgsql);

}


void *create_apache_status() {
  if(myapache_status == NULL) {
    NEW(myapache_status);
    myapache_status->name= "APACHESTATUS";
    myapache_status->check= check_apache_status;
  }
  return myapache_status;
}


void *create_default() {
  if(mydefault == NULL) {
    NEW(mydefault);
    mydefault->name= "DEFAULT";
    mydefault->check= check_default;
  }
  return mydefault;
}


void *create_dns() {
  if(mydns == NULL) {
    NEW(mydns);
    mydns->name= "DNS";
    mydns->check= check_dns;
  }
  return mydns;
}


void *create_dwp() {
  if(mydwp == NULL) {
    NEW(mydwp);
    mydwp->name= "DWP";
    mydwp->check= check_dwp;
  }
  return mydwp;
}


void *create_ftp() {
  if(myftp == NULL) {
    NEW(myftp);
    myftp->name= "FTP";
    myftp->check= check_ftp;
  }
  return myftp;
}


void *create_generic() {
  if(mygeneric == NULL) {
    NEW(mygeneric);
    mygeneric->name= "generic";
    mygeneric->check= check_generic;
  }
  return mygeneric;
}


void *create_http() {
  if(myhttp == NULL) {
    NEW(myhttp);
    myhttp->name= "HTTP";
    myhttp->check= check_http;
  }
  return myhttp;
}


void *create_imap() {
  if(myimap == NULL) {
    NEW(myimap);
    myimap->name= "IMAP";
    myimap->check= check_imap;
  }
  return myimap;
}


void *create_ldap2() {
  if(myldap2 == NULL) {
    NEW(myldap2);
    myldap2->name= "LDAP2";
    myldap2->check= check_ldap2;
  }
  return myldap2;
}


void *create_ldap3() {
  if(myldap3 == NULL) {
    NEW(myldap3);
    myldap3->name= "LDAP3";
    myldap3->check= check_ldap3;
  }
  return myldap3;
}


void *create_mysql() {
  if(mymysql == NULL) {
    NEW(mymysql);
    mymysql->name= "MYSQL";
    mymysql->check= check_mysql;
  }
  return mymysql;
}


void *create_nntp() {
  if(mynntp == NULL) {
    NEW(mynntp);
    mynntp->name= "NNTP";
    mynntp->check= check_nntp;
  }
  return mynntp;
}


void *create_ntp3() {
  if(myntp3 == NULL) {
    NEW(myntp3);
    myntp3->name= "NTP3";
    myntp3->check= check_ntp3;
  }
  return myntp3;
}


void *create_postfix_policy() {
  if(mypostfix_policy == NULL) {
    NEW(mypostfix_policy);
    mypostfix_policy->name= "POSTFIX-POLICY";
    mypostfix_policy->check= check_postfix_policy;
  }
  return mypostfix_policy;
}


void *create_pop() {
  if(mypop == NULL) {
    NEW(mypop);
    mypop->name= "POP";
    mypop->check= check_pop;
  }
  return mypop;
}


void *create_smtp() {
  if(mysmtp == NULL) {
    NEW(mysmtp);
    mysmtp->name= "SMTP";
    mysmtp->check= check_smtp;
  }
  return mysmtp;
}


void *create_ssh() {
  if(myssh == NULL) {
    NEW(myssh);
    myssh->name= "SSH";
    myssh->check= check_ssh;
  }
  return myssh;
}


void *create_rdate() {
  if(myrdate == NULL) {
    NEW(myrdate);
    myrdate->name= "RDATE";
    myrdate->check= check_rdate;
  }
  return myrdate;
}


void *create_rsync() {
  if(myrsync == NULL) {
    NEW(myrsync);
    myrsync->name= "RSYNC";
    myrsync->check= check_rsync;
  }
  return myrsync;
}


void *create_tns() {
  if(mytns == NULL) {
    NEW(mytns);
    mytns->name= "TNS";
    mytns->check= check_tns;
  }
  return mytns;
}


void *create_pgsql() {
  if(mypgsql == NULL) {
    NEW(mypgsql);
    mypgsql->name= "PGSQL";
    mypgsql->check= check_pgsql;
  }
  return mypgsql;
}

