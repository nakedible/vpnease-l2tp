''' make a "true division" function available for testing '''

from __future__ import division

def truediv(a, b): return a/b
