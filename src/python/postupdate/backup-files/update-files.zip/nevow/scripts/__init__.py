'''Command-line apps.'''
