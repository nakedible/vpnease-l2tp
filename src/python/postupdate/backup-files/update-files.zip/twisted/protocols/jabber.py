from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.jabber', 'twisted.words.protocols.jabber',
                         'Jabber protocol support', 'Words',
                         'http://twistedmatrix.com/projects/words',
                         globals())

