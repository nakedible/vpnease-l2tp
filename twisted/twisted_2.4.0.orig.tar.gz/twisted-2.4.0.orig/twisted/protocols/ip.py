from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.ip', 'twisted.pair.ip',
                         'Internet Protocol', 'Pair',
                         'http://twistedmatrix.com/projects/pair',
                         globals())

