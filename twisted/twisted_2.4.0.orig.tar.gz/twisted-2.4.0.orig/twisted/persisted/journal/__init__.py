# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.

# 

"""Command-journalling persistence framework inspired by Prevayler.

Maintainer: U{Itamar Shtull-Trauring<mailto:twisted@itamarst.org>}

API Stability: unstable
"""
