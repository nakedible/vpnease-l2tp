# -*- test-case-name: twisted.words.test -*-
# Copyright (c) 2001-2005 Twisted Matrix Laboratories.
# See LICENSE for details.


"""

Twisted X-ish: XML-ish DOM and XPath-ish engine

"""
