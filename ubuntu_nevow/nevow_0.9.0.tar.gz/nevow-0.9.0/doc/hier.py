title = { 
        "en" : "Nevow Manual"
        }

hier = \
( 
{"nevow-intro":("Introduction",None)},
{"nevow-gettingstarted":("Getting Started",None)},
{"nevow-traversal":("Object Traversal",None)},
{"nevow-rendering":("Object Publishing",None)},
{"nevow-xml-templates":("XML Templates",None)},
{"nevow-deployment":("Deploying Nevow Applications",None)},
{"nevow-glossary":("Glossary",None)},

#{"other":("Other",
#    (
#    {"blah":("Blah",
#        (
#        {"bar":("Bar",None)},
#        ))},
#    ))},

)
